#include <stdio.h>
#include <stdlib.h>
#include <bits/stdc++.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/stat.h>
//#include "exev_1.cpp"
//#include "read_Input(string s)"

using namespace std;

char r[100];
char *temp[100];


int main(){
	string s;
	getline(cin,s);
	//read_Input();
	strcpy(r,s.c_str());
	char *p = strtok(r," ");
	temp[0]=p;

	int i=0;
	while(p){
		p = strtok(NULL," ");
		temp[++i]=p;
	}
	char *s1 = temp[3];
	//cout<<temp[3];
//	cout<<*s1;
	//int fd1 = open(s,O_RDONLY);
	
	//cout<<fd2;
		int fd2,fd3;

		if(!strcmp(temp[i-2],">")){
			fd2= open(s1,O_CREAT | O_WRONLY);
			dup2(fd2,1);
			temp[i-1]=NULL;
			temp[i-2]=NULL;
		}

		else if(!strcmp(temp[i-2],">>")){
			fd3 = open(s1,O_CREAT | O_WRONLY | O_APPEND);
			dup2(fd3,1);
			temp[i-1]=NULL;
			temp[i-2]=NULL;
		}
	//close(fd2);
	//close(fd3);

	execvp(temp[0],temp);
	return 0;
}
