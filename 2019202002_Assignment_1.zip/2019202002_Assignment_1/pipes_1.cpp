#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string.h>

using namespace std;

char *temp[100];
char *t[100];
char r[100];

static char* skipwhite(char* s)
{
  while (isspace(*s)) ++s;
  return s;
}


void input(string s){
	strcpy(r,s.c_str());
	char *a = strtok(r," ");
	t[0]=a;
	cout<<t[0];

	int j=0;
	while(a){
		a = strtok(NULL," ");
		t[++j]=a;
		cout<<t[++j];
	}
cout<<"**"<<t[1];
}

void pipe(string s){
	char str[100] ;
	strcpy(str,s.c_str());
	char *p = strtok(str,"|");
	temp[0] = p;
	cout<<temp[0];
	input(temp[0]);
	char *g = temp[0];
	//cout<<strlen(p);
	//cout<<temp[0];  // ls -l more
	int i=0;
	while(p){
		p = strtok(NULL,"|");
		temp[++i]=p;

	}
	//cout<<temp[1]<<endl;
	
	temp[1] = skipwhite(temp[1]);
	//cout<<temp[1]; //more


	pid_t pid1;
	int pipefd[2];

	pipe(pipefd);
	pid1 = fork();
	if(pid1 == 0){
	  dup2(pipefd[1], STDOUT_FILENO);
      close(pipefd[0]);
      execvp(t[0], t);
     perror("exec");
	cout<<t;
	}
	//pid2 = fork();
   if(pid1 != 0) {
      
      dup2(pipefd[0], STDIN_FILENO);
      close(pipefd[1]);
     
      execvp(temp[1], temp);
   }
   
   close(pipefd[0]);
   close(pipefd[1]);
 //   waitpid(pid1);
 
}

int main(){
	string s;
	getline(cin,s);
	pipe(s);
	//input(s);
	return 0;
}
