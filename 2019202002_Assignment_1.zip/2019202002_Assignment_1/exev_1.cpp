#include<bits/stdc++.h>
#include<iostream>
#include<unistd.h>
#include<cstdio>
#include<string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include<fcntl.h>
#include<errno.h>
#include<pwd.h>
//#include "redirection.cpp"
using namespace std;
char *getcwd(char *buf,size_t size);//gives the path of current folder
char *getwd(char *buf);
char *get_current_dir_name(void);

char r[100];
char *temp[100];
char cwd[1024];
char current_directory[1000];


void input(string s){
	strcpy(r,s.c_str());
	char *p = strtok(r," ");
	temp[0]=p;

	int i=0;
	while(p){
		p = strtok(NULL," ");
		temp[++i]=p;
	}
}

void path_find(){
if (getcwd(cwd, sizeof(cwd)) != NULL)
         printf("%s\n", cwd );
}

int exec_cmd(string s) {
	input(s);

	if(strcmp("pwd",temp[0])==0)
		path_find();

	pid_t pid = fork();

	if (pid < 0) {
		perror("fork error");
	} else if (pid == 0) {
		
		execvp(temp[0], temp);
	}
	wait(NULL);
	return 0;
}

void prompt()
{
  
   if (getcwd(cwd, sizeof(cwd)) != NULL)
        {
          struct passwd *getpwuid(uid_t uid);
          struct passwd *p;
    		uid_t uid=0;
    		p = getpwuid(uid); 
    
        printf("%s@%s#", p->pw_name,cwd);
        }
}



int main(){

	getcwd(current_directory, sizeof(current_directory));
	while(1){
		prompt();
		string s;
		getline(cin,s);
		exec_cmd(s);
	
	}
	
	return 0;
}